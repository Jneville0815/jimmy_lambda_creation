import os
from twilio.rest import Client


def lambda_handler(event, context):
    account_sid = os.environ['TWILIO_ACCOUNT_SID']
    auth_token = os.environ['TWILIO_AUTH_TOKEN']
    twilio_number = os.environ['TWILIO_PHONE_NUMBER']

    client = Client(account_sid, auth_token)

    message = client.messages \
        .create(
        body="This is a test",
        from_=twilio_number,
        to='+18654408251'
    )

    print(f"Text message sent (Message: {message.body}. Error: {message.error_message})")